#!/bin/sh

TSLIB_TSDEVICE=/dev/touchscreen0

export TSLIB_TSDEVICE


#!/bin/sh

PATH=$PATH:/system/bin:/system/xbin
export PATH


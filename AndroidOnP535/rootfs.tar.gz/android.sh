#!/system/bin/sh -x
echo "Starting Android..."
#./busybox cat /dev/input/event0
./init
#./strace -ff -F -tt -s 200 -o /data/local/tmp/ ./service zygote /system/bin/app_process -Xzygote /system/bin --zygote --start-system-server


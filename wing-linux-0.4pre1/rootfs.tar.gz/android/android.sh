#!/system/bin/sh

export LD_LIBRARY_PATH=/system/lib
export ANDROID_BOOTLOGO=1
export ANDROID_ROOT=/system
export ANDROID_ASSETS=/system/app
export ANDROID_DATA=/data
export EXTERNAL_STORAGE=/sdcard
export DRM_CONTENT=/data/drm/content

export TSLIB_CONSOLEDEVICE=none
export TSLIB_FBDEVICE=/dev/fb0
export TSLIB_TSDEVICE=/dev/input/event1
export TSLIB_CALIBFILE=/etc/pointercal
export TSLIB_COINFFILE=/etc/ts.conf
export TSLIB_PLUGINDIR=/usr/lib/ts

/init &
/system/bin/sleep 2

/system/bin/umount /sys
/system/bin/umount /sys
/system/bin/umount /sys
/system/bin/umount /sys
/system/bin/umount /sys
/system/bin/umount /sys
/system/bin/umount /sys
/system/bin/chmod 666 /dev/ttyCSMI0
/system/bin/chmod 666 /dev/ttyCSMI1
/system/bin/ln -s /dev/ttyCSMI0 /dev/ttyS0
/system/bin/ln -s /dev/ttyCSMI1 /dev/omap_csmi_tty1

#/system/bin/app_process -Xzygote /system/bin --zygote &
#/system/bin/dbus-daemon --system &
#runtime

-----------------------------------------------------------------------------
All Mobile Mines - Professional/Classic Edition
-----------------------------------------------------------------------------
Web Site.....   http://www.binaryfish.com
Forum........   http://www.binaryfish.com/forum
E-mail.......   support@binaryfish.com

Copyright (c) 2007-2008 Binaryfish
Version 4.0.2
Modified: 2008/3/3

Table of contents           
        1. File contents
        2. Introduction
        3. Requirements
        4. Installation
        5. What's New
        6. License


-----------------------------------------------------------------------------
1. FILE CONTENTS
-----------------------------------------------------------------------------
If the file is distributed in a ZIP file then it will contain 2 files:

   1. AllMobileMines_Setup.exe
   2. Readme.txt (this file)
   
-----------------------------------------------------------------------------
2. INTRODUCTION
-----------------------------------------------------------------------------
Free Minesweeper game. The objective of the game is to locate all the mines 
as quickly as possible without uncovering any of them. If you uncover a mine 
you lose the game.


-----------------------------------------------------------------------------
3. REQUIREMENT
-----------------------------------------------------------------------------
- Windows Mobile 6 Professional/Classic, Windows Mobile 5.0 for Pocket PC, 
  Windows Mobile 2003 Second Edition for Pocket PC, Windows Mobile 2003 for 
  Pocket PC. For the Windows Mobile 6 Standard and Windows Mobile 5.0 for
  Smartphone Edition please visit our Web site to download:
  www.binaryfish.com

- 280 KB of storage space and 3 MB of runtime RAM. 
 
- To install the program you need Windows with ActiveSync installed. You can
  also download the All Mobile Mines CAB file for over-the-air installation 
  from our Web site.


-----------------------------------------------------------------------------
4. INSTALLATION
-----------------------------------------------------------------------------
To install the program simply double-click on the Setup.exe file on Windows.

UNINSTALLING THE PROGRAM

To uninstall from the Pocket PC, on the Start menu, tap Settings > System >
Remove Programs, and select Binaryfish All Mobile Mines and finally press the 
Remove button.


-----------------------------------------------------------------------------
5. WHAT'S NEW
-----------------------------------------------------------------------------
4.0.2   - Fixed random game bug.
        - Minor user interface updates.

4.0.1   - Fixed compatibility problem with Windows Mobile 2003 for Pocket PC
          devices.
        - Timer will automatically pause when game is sent to the background.
        - Added option to check and download latest version directly from
          game.
4.0.0   - Official release.
       

-----------------------------------------------------------------------------
6. LICENSE
-----------------------------------------------------------------------------
License

You should carefully read the following terms and conditions before using 
All Mobile Mines - Pocket PC Edition (hereinafter the "SOFTWARE"). Your use 
of the SOFTWARE indicates your acceptance of this License.

1. License
The SOFTWARE is licensed, not sold, to you by Binaryfish for use only under 
the terms of this License, and Binaryfish reserves any rights not expressly 
granted to you. Binaryfish grants to you the license to use a single copy of 
the SOFTWARE. The SOFTWARE may not be rented, loaned, leased, or licensed, 
to any one else. You must have written permission from Binaryfish to 
redistribute the SOFTWARE.

2. Ownership
The SOFTWARE is owned and copyrighted by Binaryfish. Your license confers no
title or ownership in the SOFTWARE and should not be construed as a sale of
any right in the SOFTWARE.

3. Copyright
The SOFTWARE is protected international treaty provisions. You acknowledge
that no title to the intellectual property in the SOFTWARE is transferred to
you. You further acknowledge that title and full ownership rights to the
SOFTWARE will remain the exclusive property of Binaryfish and you will not
acquire any rights to the SOFTWARE except as expressly set forth in this
license. You agree that any copies of the SOFTWARE will contain the same
proprietary notices which appear on and in the SOFTWARE.

4. Restrictions
You agree that you will not attempt to reverse compile, modify, adapt,
translate, copy, emulate, clone, disassemble the SOFTWARE in whole or in
part, or otherwise attempt to discover the source code of the SOFTWARE
(except and solely to the extent an applicable statute expressly and
specifically prohibits such restrictions). You may not remove any proprietary
notices or labels on the SOFTWARE. Usage of the SOFTWARE may violate the
copyright of the modified material. It is your responsibility to respect all
legal aspects.

5. Disclaimer of Warranty
THE PROGRAM IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESS
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY OR
FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT WILL BINARYFISH BE LIABLE TO
YOU FOR ANY DAMAGES, INCLUDING INCIDENTAL OR CONSEQUENTIAL DAMAGES, ARISING
OUT OF THE USE OF THE SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGES.

YOU ACKNOWLEDGE THAT YOU HAVE READ THIS LICENSE, UNDERSTAND IT AND AGREE TO
BE BOUND BY ITS TERMS AS THE COMPLETE AND EXCLUSIVE STATEMENT OF THE
AGREEMENT BETWEEN US, SUPERSEDING ANY PROPOSAL OR PRIOR AGREEMENT, ORAL OR
WRITTEN, AND ANY OTHER COMMUNICATIONS BETWEEN US RELATING TO THE SUBJECT
MATTER OF THIS LICENSE.

6. Termination
This Agreement and the license granted hereunder will terminate automatically
if you fail to comply with the limitations described herein. Upon
termination, you must destroy all copies of the SOFTWARE and documentation.

-----------------------------------------------------------------------------

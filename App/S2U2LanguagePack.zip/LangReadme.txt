Language Pack for S2U2 v0.80 or later

How to install
==============
Through S2U2 Settings (for v2.10 or later):
- copy the whole zip file to S2U2 installed folder
- run S2U2 Settings -> Language -> select your language
- save

Manually:
- extract your language's ini file
- rename it to lang.ini
- copy it to the S2U2 installed folder
- restart iLock2

If you need to modify the ini file, make sure it's saved in UNICODE format.
The lang.English.ini file is for reference.

The lang.ini file not only changes the language, it can also be used to set up the various default options for 
S2UText, S2AText, S2VText, s_S2DDismiss, s_S2DCancel, s_S2DView, s_CS2UText, DateFormat, TimeFormat & ClockPath.

History
=======
v2.00 (18-6-2009)
- please refer to the lang.English.ini for all the changes

v1.62 (2-4-2009)
- removed "s_ShowMsgPreview"
- added "s_ShowSMSPreview", "s_ShowMMSPreview", "s_ShowEmailPreview", "s_PowerButtonEndCall"

v1.60 (27-3-2009)
- added "s_S2VText", "s_Owner", "s_LockNotification", "s_AutoDismissNotification", "s_ShowMsgPreview", "s_ShowAllDay",
 "s_Time2Format", "s_Clock2Path", "s_ShowOwnerInfo", "s_VibrationLED", "s_NoManilaLock", "s_EmailPreviewDelayMS"

v1.52 (5-3-2009)
- added "s_RequirePassword", "s_Immediately", "s_After1minute", "s_After5minutes", "s_After15minutes",
 "s_After1hour", "s_After4hours", "s_After12hours", "s_TopmostCurtain", "s_S2PBT"

v1.50 (23-2-2009)
- added "s_EnterPw", "s_WrongPw", "s_SendSMS", "s_BusySMSBody", "s_Send", "s_Left", "s_Center", "s_Right",
 "s_EnterNewPw", "s_ReenterPw", "s_EnterOldPw", "s_EnterWrongPw", "s_On", "s_Off", "s_PasswordLock",
 "s_AppointmentLine", "s_AlignAppointment", "s_SendBusySMS", "s_S2PControl", "s_HapticFeedback"

v1.42 (15-1-2009)
- added "s_VibrateOnConnect"

v1.41 (14-1-2009)
- added "s_SliderInertia"

v1.40 (29-12-2008)
- added "s_PowerSave", "s_DigitalBattery"

v1.36 (14-12-2008)
- changed "s_UnlockOnAC" to "s_ActionOnAC"
- added "s_Lock", "s_Unlock", "s_Unlock2Home", "s_IgnoreScreenRotation"

v1.33 (25-10-2008)
- added "s_HPcloseS2P"

v1.32 (19-10-2008)
- added "s_DisplayMode", "s_S2End", "s_ShowBattery", "s_ShowMMS"

v1.30 (15-10-2008)
- added "s_S2UText", "s_S2AText", "s_S2EAnswer", "s_S2EEnd", "s_Appearance", "s_BottomCurtain",
 "s_HPstartS2P", "s_UnlockOnAC", "s_StylusOutUnlock", "s_StylusInLock", "s_WakeUpDelayMS", "s_BlankOnTalkDelayMS"

v1.22 (9-9-2008)
- changed "s_ShowAppointment" to "No. of Appointment"
- added "s_DefaultAptDateFormat1", "s_DefaultAptDateFormat2", "s_DefaultAptDateFormat3", "s_Appointment",
 "s_AppointmentDays", "s_AppointmentDateFormat", "s_Charging"

v1.20 (28-8-2008)
- changed "s_ShowAppointment" to "No. of Next Week Appointment Info"
- added "s_Blankstart", "s_ExceptionEXEFG"

v1.13 (1-8-2008)
- remove "s_NoSubject"

v1.10 (29-7-2008)
- changed "s_ShowAppointment" to "No. of Today/Tomorrow Appointment Info"
- added "s_Tomorrow", "s_NoSubject", "s_Vibrate", "s_Silent", "s_OnlyLocked", "s_Always", "s_VolumeControl",
 "s_TransparentVC", "s_UnlockOnRotate", "s_NoS2P", "s_NoBackLightCheck", "s_NoKeyBoardHook"

v1.02 (3-6-2008)
- added "s_S2AAnsKey"

v0.96 (27-12-2007)
- changed "s_GifSpeed" to "Override GIF Speed (1-slow; 10-fast)"
- changed "s_WallpaperChangeTime" to "Change JPG Wallpaper Every"
- changed "s_WallpaperRandom" to "Change JPG Wallpaper Randomly"
- added "s_GifEndless"

v0.95 (19-12-2007)
- changed "s_Autostart" to "Lock when device wakes up"
- changed "s_Idlestart" to "Lock when backlight turns off"
- changed "s_ShowAlarm" to "Next Alarm Info"
- changed "s_ShowAppointment" to "Current/Next Appointment Info"
- changed "s_DpadOn" to "DPAD"
- added "s_ClockPath", "s_DefaultClockPath1", "s_DefaultClockPath2", "s_DefaultClockPath3",
 "s_DefaultClockPath4", "s_DefaultClockPath5", "s_ShowWeather", "s_S2AEndKey", "s_Wallpaper",
 "s_FileDirectoryPortrait", "s_DefaultWallpaper1", "s_DefaultWallpaper2", "s_DefaultWallpaper3",
 "s_DefaultWallpaper4", "s_DefaultWallpaper5", "s_FileDirectoryLandscape", "s_DefaultWallpaperL1",
 "s_DefaultWallpaperL2", "s_DefaultWallpaperL3", "s_DefaultWallpaperL4", "s_DefaultWallpaperL5",
 "s_GifSpeed", "s_WallpaperChangeTime", "s_WallpaperRandom", "s_NoSoftKey", "s_TopCurtain", "s_KoreanSMSpatch"

v0.86 (20-11-2007)
- added "s_LastCall", "s_Phone", "s_PhoneNoFormat", "s_DefaultPhoneNoFormat1",
 "s_DefaultPhoneNoFormat2" & "s_DefaultPhoneNoFormat3"

v0.83 (15-11-2007)
- changed "s_AppointmentTimeFormat" to "Alarm/Appointment Time Format"
- added "s_Slide2Answeer"

v0.81 (10-11-2007)
- changed all identifiers from "txt_" to "s_"
- added support to "s2u2 Settings"

v0.72 (30-10-2007)
- initial release

Enjoy!
A_C
Reboot PokeP
v1.01
For Windows Mobile 5.0
Written by jsurfer
http://home.comcast.net/~cheezsj/



'Reboot PokeP' is a Today plugin which allows you to reboot your Windows
Mobile 5.0 device by tapping on icon.



HOW TO INSTALL:

Place 'Reboot_Poke_P.CAB' file on Windows Mobile 5.0 device and tap on
the file to install.



SETTING UP AFTER THE INSTALLATION:

Once the installation is complete, you will need to add 'Reboot PokeP'
icon to Today's screen by following these steps:

 1) From 'Start' menu, select 'Settings'
 2) In 'Settings' screen, tap on 'Personal' tab
 3) Tap on 'Today' icon
 4) In 'Today settings' screen, tap on 'Items' tab
 5) Check the checkbox for 'Reboot_Poke_P' and tap on [ok] button



HOW TO UNINSTALL:

 1) From 'Start' menu, select 'Settings'
 2) In 'Settings' screen, tap on 'System' tab
 3) Tap on 'Remove Programs' icon
 4) Select 'jsurfer Reboot_Poke_P' from the list and tap on [Remove]
button



INSTALLED FILE(S) AND ADDED/MODIFIED REGISTRY

    Program Files\Reboot_Poke_P\Reboot_Poke_P.dll

    HKEY_CURRENT_USER\Software\jsurfer
    HKEY_LOCAL_MACHINE\Software\jsurfer
    HKEY_LOCAL_MACHINE\Software\Microsoft\Today\Items\Reboot_Poke_P



RELEASE HISTORY:

August 22, 2006: Version 1.0
 - First release

November 08, 2006: Version 1.01
 - Now uses 32x32 icon instead of 16x16 icon when run on RealVGA'd device



COPYRIGHT:

This software is copyright 2006 by jsurfer.



DISTRIBUTION:

Any distribution of 'Reboot PokeP' must include all of the files
in their original condition, without removal, addition or modification.
'Reboot PokeP' may not be sold, resold, included as part of a
commercial package or used for any other commercial purpose without
the prior written consent of the author.



DISCLAIMER:

'Reboot PokeP' is supplied as is. The author disclaims all warranties,
expressed or implied, including, without limitation, the warranties of
merchantability and of fitness for any purpose. The author assumes no
liability for damages, direct or consequential, which may result from
the use of 'Reboot PokeP'.



Copyright (C)2006 jsurfer. All rights reserved.
